$(document).ready(function() {
    $('#signinForm').on('submit', function(e) {
        e.preventDefault();

        const username = $('#usernameInputSignin').val();
        const password = $('#passwordInputSignin').val();

        $.ajax({
            type: 'POST',
            url: '/login',
            data: {
                username: username,
                password: password
            },
            success: function(response) {
                if (response.message === 'Login successful') {
                    window.location.href = '/main.html'; // Redirect to the main control panel page
                } else {
                    alert('Invalid credentials');
                }
            },
            error: function() {
                alert('Error logging in');
            }
        });
    });
});

