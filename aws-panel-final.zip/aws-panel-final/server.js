const express = require('express');
const bodyParser = require('body-parser');
const { exec } = require('child_process');
const httpProxy = require('http-proxy');
const fetch = require('node-fetch');

const app = express();

// Create the proxy with the correct options
const proxy = httpProxy.createProxyServer({
    target: 'http://192.168.203.151:8080',
    ws: true,
    proxyTimeout: 60000  // Set timeout to 60 seconds
});

// Serve static files from the 'public' directory
app.use(express.static('public'));
app.use(bodyParser.json());

app.post('/api/start', (req, res) => {
    const instanceId = req.body.instanceId;
    exec(`aws ec2 start-instances --instance-ids ${instanceId}`, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).send('Error starting instance');
        }
        res.send('Instance started');
    });
});

app.post('/api/stop', (req, res) => {
    const instanceId = req.body.instanceId;
    exec(`aws ec2 stop-instances --instance-ids ${instanceId}`, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).send('Error stopping instance');
        }
        res.send('Instance stopped');
    });
});

app.post('/api/status', (req, res) => {
    const instanceId = req.body.instanceId;

    exec(`aws ec2 describe-instances --instance-ids ${instanceId}`, (error, stdout, stderr) => {
        if (error) {
            console.error(`exec error: ${error}`);
            return res.status(500).send('Error fetching VM status');
        }

        const data = JSON.parse(stdout);
        const instance = data.Reservations[0].Instances[0];
        res.json({ status: instance.State.Name });
    });
});

app.get('/startRDP', async (req, res) => {
    const token = await getGuacamoleToken();
    res.json({ token });
});


async function getGuacamoleToken() {
    const response = await fetch('http://192.168.203.151/guacamole/api/tokens', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `username=admin&password=admin`
    });

    const data = await response.json();
    return data.authToken;
}


//Lab Runtime
app.get('/api/getLabMetrics', (req, res) => {
    // Fetch data from database or any other source
    const data = {
        todaysBookings: 4006,
        totalBookings: 61344,
        todaysPercentage: 10.00,
        totalPercentage: 22.00
    };
    res.json(data);
});


// Reverse proxy setup
app.all('/guacamole/*', (req, res) => {
    proxy.web(req, res);
});

// WebSocket upgrade
app.on('upgrade', (req, socket, head) => {
    proxy.ws(req, socket, head);
});

proxy.on('error', (error, req, res) => {
    res.writeHead(500, {
        'Content-Type': 'text/plain'
    });
    res.end('Something went wrong. Please try again later.');
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});

